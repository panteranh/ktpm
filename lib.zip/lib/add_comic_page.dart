import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mangaapp1/models/comic_model.dart';

enum ImageSourceType { url, upload }

class AddComicPage extends StatefulWidget {
  const AddComicPage({Key? key}) : super(key: key);

  @override
  State<AddComicPage> createState() => _AddComicPageState();
}

class _AddComicPageState extends State<AddComicPage> {
  final _formKey = GlobalKey<FormState>();
  // Controllers for text fields
  final _titleController = TextEditingController();
  final _authorController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _coverUrlController = TextEditingController();

  // State for Genre Chips
  final List<String> _availableGenres = [
    'Action', 'Adventure', 'Comedy', 'Drama', 'Fantasy', 'Horror', 'Magic', 
    'Mecha', 'Mystery', 'Psychological', 'Romance', 'Sci-Fi', 'Slice of Life'
  ];
  List<String> _selectedGenres = [];
  
  // --- NEW: State for Status ---
  String _selectedStatus = 'Ongoing';

  // State for image handling
  ImageSourceType _imageSource = ImageSourceType.url;
  File? _imageFile;
  bool _isUploading = false;

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  Future<String?> _uploadImage() async {
    if (_imageFile == null) return null;

    try {
      final fileName = 'cover_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final destination = 'comic_covers/$fileName';
      final ref = FirebaseStorage.instance.ref(destination);
      await ref.putFile(_imageFile!);
      return await ref.getDownloadURL();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi tải ảnh lên: $e')),
      );
      return null;
    }
  }

  Future<void> _saveComic() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
     if (_selectedGenres.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Vui lòng chọn ít nhất một thể loại')),
      );
      return;
    }

    setState(() {
      _isUploading = true;
    });

    String? coverUrl;

    if (_imageSource == ImageSourceType.upload) {
      if (_imageFile == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Vui lòng chọn một ảnh để tải lên')),
        );
        setState(() => _isUploading = false);
        return;
      }
      coverUrl = await _uploadImage();
      if (coverUrl == null) {
        setState(() => _isUploading = false);
        return; // Stop if upload failed
      }
    } else {
      coverUrl = _coverUrlController.text.trim();
    }

    final newComic = Comic(
      title: _titleController.text.trim(),
      author: _authorController.text.trim(),
      genre: _selectedGenres.join(', '), 
      description: _descriptionController.text.trim(),
      cover: coverUrl,
      status: _selectedStatus, // Add status
      createdAt: Timestamp.now(),
    );

    try {
      await FirebaseFirestore.instance.collection('comics').add(newComic.toJson());

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Đã lưu truyện mới lên Firestore!'), backgroundColor: Colors.green),
        );
        Navigator.pop(context, true); 
      }
    } catch (e) {
       if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Lỗi lưu truyện: $e')),
        );
      }
    }

    setState(() {
      _isUploading = false;
    });
  }

  @override
  void dispose() {
    _titleController.dispose();
    _authorController.dispose();
    _descriptionController.dispose();
    _coverUrlController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Thêm / Sửa truyện'),
        actions: [
          IconButton(
            icon: _isUploading ? const SizedBox.shrink() : const Icon(Icons.save_alt_outlined),
            onPressed: _isUploading ? null : _saveComic,
          )
        ],
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildImageSection(),
              const SizedBox(height: 24),
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: 'Tên truyện', border: OutlineInputBorder()),
                validator: (v) => v!.isEmpty ? 'Vui lòng nhập tên truyện' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _authorController,
                decoration: const InputDecoration(labelText: 'Tác giả', border: OutlineInputBorder()),
                validator: (v) => v!.isEmpty ? 'Vui lòng nhập tác giả' : null,
              ),
              const SizedBox(height: 16),
              _buildGenreSection(),
              const SizedBox(height: 16),
              _buildStatusSection(), // Add status section
              const SizedBox(height: 16),
              TextFormField(
                controller: _descriptionController,
                decoration: const InputDecoration(labelText: 'Mô tả', border: OutlineInputBorder()),
                maxLines: 4,
                 validator: (v) => v!.isEmpty ? 'Vui lòng nhập mô tả' : null,
              ),
              const SizedBox(height: 32),
              ElevatedButton.icon(
                onPressed: _isUploading ? null : _saveComic,
                icon: _isUploading 
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3))
                    : const Icon(Icons.save_alt_outlined),
                label: Text(_isUploading ? 'Đang lưu...' : 'Lưu truyện'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: const TextStyle(fontSize: 18),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildImageSection() {
     return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Ảnh bìa', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        SegmentedButton<ImageSourceType>(
          segments: const [
            ButtonSegment(value: ImageSourceType.url, label: Text('Từ URL'), icon: Icon(Icons.link)),
            ButtonSegment(value: ImageSourceType.upload, label: Text('Tải lên'), icon: Icon(Icons.upload_file)),
          ],
          selected: {_imageSource},
          onSelectionChanged: (newSelection) {
            setState(() {
              _imageSource = newSelection.first;
            });
          },
        ),
        const SizedBox(height: 16),
        if (_imageSource == ImageSourceType.url)
          TextFormField(
            controller: _coverUrlController,
            decoration: const InputDecoration(labelText: 'URL ảnh bìa', border: OutlineInputBorder()),
            validator: (value) {
              if (_imageSource == ImageSourceType.url && (value == null || value.isEmpty)) {
                return 'Vui lòng nhập URL ảnh bìa';
              }
              if (value != null && value.isNotEmpty && !Uri.tryParse(value)!.isAbsolute) {
                  return 'URL không hợp lệ';
              }
              return null;
            },
          )
        else
          _buildImageUpload(),
      ],
    );
  }

  Widget _buildImageUpload() {
    return Column(
      children: [
        Container(
          height: 150,
          width: double.infinity,
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade400),
            borderRadius: BorderRadius.circular(8),
            color: Colors.grey.shade100,
          ),
          child: _imageFile != null
              ? ClipRRect(borderRadius: BorderRadius.circular(7), child: Image.file(_imageFile!, fit: BoxFit.cover))
              : const Center(child: Text('Xem trước ảnh', style: TextStyle(color: Colors.grey))),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: _pickImage,
          icon: const Icon(Icons.photo_library_outlined),
          label: const Text('Chọn ảnh từ thư viện'),
        ),
      ],
    );
  }

  Widget _buildGenreSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Thể loại', style: Theme.of(context).textTheme.titleMedium),
            IconButton(
              icon: const Icon(Icons.edit_note, color: Colors.deepPurple),
              onPressed: () => _showGenrePickerDialog(),
              tooltip: 'Chỉnh sửa thể loại',
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(12),
          width: double.infinity,
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade400),
            borderRadius: BorderRadius.circular(8),
          ),
          child: _selectedGenres.isEmpty
              ? Text('Chưa chọn thể loại nào', style: TextStyle(color: Colors.grey.shade600))
              : Wrap(
                  spacing: 8.0,
                  runSpacing: 8.0,
                  children: _selectedGenres.map((genre) => Chip(
                    label: Text(genre),
                    backgroundColor: Colors.deepPurple.shade50,
                    labelStyle: const TextStyle(color: Colors.deepPurple),
                    onDeleted: () {
                      setState(() {
                        _selectedGenres.remove(genre);
                      });
                    },
                  )).toList(),
                ),
        ),
      ],
    );
  }
  
  // --- NEW: Widget for Status Section ---
   Widget _buildStatusSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Trạng thái', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'Ongoing', label: Text('Đang tiến hành')),
            ButtonSegment(value: 'Completed', label: Text('Hoàn thành')),
             ButtonSegment(value: 'Hiatus', label: Text('Tạm dừng')),
          ],
          selected: {_selectedStatus},
          onSelectionChanged: (newSelection) {
            setState(() {
              _selectedStatus = newSelection.first;
            });
          },
        ),
      ],
    );
  }


  Future<void> _showGenrePickerDialog() async {
    final tempSelectedGenres = List<String>.from(_selectedGenres);

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Chọn thể loại'),
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SingleChildScrollView(
                child: Wrap(
                  spacing: 8.0,
                  children: _availableGenres.map((genre) {
                    final isSelected = tempSelectedGenres.contains(genre);
                    return FilterChip(
                      label: Text(genre),
                      selected: isSelected,
                      onSelected: (bool selected) {
                        setState(() {
                          if (selected) {
                            tempSelectedGenres.add(genre);
                          } else {
                            tempSelectedGenres.remove(genre);
                          }
                        });
                      },
                    );
                  }).toList(),
                ),
              );
            },
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Hủy'),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _selectedGenres = tempSelectedGenres;
                });
                Navigator.pop(context);
              },
              child: const Text('Xác nhận'),
            ),
          ],
        );
      },
    );
  }
}
