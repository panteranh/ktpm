import 'package:flutter/material.dart';

class AdminPanelPage extends StatelessWidget {
  const AdminPanelPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bảng điều khiển Admin'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          ListTile(
            leading: const Icon(Icons.people_alt_outlined),
            title: const Text('Quản lý người dùng'),
            onTap: () {},
          ),
          ListTile(
            leading: const Icon(Icons.book_online_outlined),
            title: const Text('Quản lý truyện'),
            onTap: () {},
          ),
          ListTile(
            leading: const Icon(Icons.analytics_outlined),
            title: const Text('Xem thống kê'),
            onTap: () {},
          ),
        ],
      ),
    );
  }
}
