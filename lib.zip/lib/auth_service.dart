import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter/foundation.dart' show kIsWeb, defaultTargetPlatform, TargetPlatform;

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  GoogleSignIn? _googleSignIn;

  AuthService() {
    if (_isGoogleSignInSupported()) {
      _googleSignIn = GoogleSignIn();
    }
  }

  // Stream to listen to auth state changes
  Stream<User?> get user => _auth.authStateChanges();

  // Helper to check if we are on a platform that supports Google Sign-In
  bool _isGoogleSignInSupported() {
    if (kIsWeb) return true;
    try {
      return defaultTargetPlatform == TargetPlatform.android ||
             defaultTargetPlatform == TargetPlatform.iOS;
    } catch (e) {
      return false;
    }
  }

  // Sign in with Google
  Future<User?> signInWithGoogle() async {
    if (!_isGoogleSignInSupported() || _googleSignIn == null) {
      print('Google Sign-In is not supported on this platform.');
      throw UnsupportedError('Google Sign-In is not supported on this platform.');
    }
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn!.signIn();
      if (googleUser == null) {
        return null; // User cancelled the sign-in
      }
      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      final UserCredential userCredential = await _auth.signInWithCredential(credential);
      return userCredential.user;
    } catch (e) {
      print(e); // For debugging
      return null;
    }
  }

  // Register with email & password
  Future<User?> registerWithEmailAndPassword(String email, String password) async {
    try {
      final UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      return userCredential.user;
    } on FirebaseAuthException catch (e) {
      print(e.message);
      return null;
    }
  }

  // Sign in with email & password
  Future<User?> signInWithEmailAndPassword(String email, String password) async {
    try {
      final UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return userCredential.user;
    } on FirebaseAuthException catch (e) {
      print(e.message);
      return null;
    }
  }

  // Sign out
  Future<void> signOut() async {
    if (_isGoogleSignInSupported() && _googleSignIn != null) {
       // Check if a user was previously signed in with Google
      if (await _googleSignIn!.isSignedIn()) {
        await _googleSignIn!.signOut();
      }
    }
    await _auth.signOut();
  }
}
